# Test de Humanidad
Una prueba divertida con chistes y acertijos para evaluar qué tan humano eres.